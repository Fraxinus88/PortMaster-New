# Credits

## Creators of Mineclonia
* ryvnf
* cora

## Creator of MineClone 2
* Wuzzy

## Creator of MineClone
* davedevils

## Active Contributors
* codiac
* ShadowRoi
* nixnoxus
* chmodsayshello
* laireia
* nixnoxus
* the-real-herowl
* JoseDouglas26
* Eliy21

## Previous Contributors
* Lizzy Fleckenstein
* AFCMS
* NO11
* Brandon
* kay27
* marcin-serwin
* Michieal
* epCode
* PrairieWind
* iliekprogrammar
* ancientmarinerdev
* TheOnlyJoeEnderman
* jordan4ibanez
* FossFanatic
* rubenwardy
* SumianVoice
* MysticTempest
* HimbeerserverDE
* MrRar
* kabou
* FaceDeer
* Nils Dagsson Moskopp
* ChrisPHP
* 3raven

## Original Mod Authors
* Wuzzy
* Fleckenstein
* BlockMen
* TenPlus1
* PilzAdam
* ryvnf
* stujones11
* Arcelmi
* celeron55
* maikerumine
* GunshipPenguin
* Qwertymine3
* Rochambeau
* rubenwardy
* stu
* 4aiman
* Kahrl
* Krock
* UgnilJoZ
* lordfingle
* 22i
* bzoss
* kilbith
* xeranas
* kddekadenz
* sofar
* 4Evergreen4
* jordan4ibanez
* paramat
* cora

## 3D Models
* 22i
* tobyplowy
* epCode

## Textures and menu images
* XSSheep
* Wuzzy
* kingoscargames
* leorockway
* xMrVizzy
* yutyo
* NO11
* kay27
* MysticTempest
* RandomLegoBrick
* cora
* Michieal
* ryvnf
* SmokeyDope
* Aeonix_Aeon
* Nicu
* Exhale
* Aeonix_Aeon
* Wbjitscool
* SmokeyDope

## Translations
* Wuzzy
* Rocher Laurent
* wuniversales
* kay27
* pitchum
* todoporlalibertad
* Marcin Serwin
* Pepebotella
* Emojigit
* snowyu
* 3raven
* Riu Sakura

## Special thanks
* celeron55 for creating Minetest
* Jordach for the jukebox music compilation from Big Freaking Dig
* The workaholics who spent way too much time writing for the Minecraft Wiki.
  It's an invaluable resource for creating this game
* Notch and Jeb for being the major forces behind Minecraft
