mcl_campfires
===============
Adds the campfire and its soul variant.

License of code
---------------
See the main MineClone 2 README.md file.
Authors:
Gerold55 - Code Start + Models?
PrairieWind - Improved and Cleaned Up Code, and added the soul campfire and crafting recipes.
cora - Added burning damage.
DinoNuggies4665 - Cooking logic implemented
thunder1035 - Redesigned model and texture tweaks
AncientMariner - Changed smoke to particle spawner and tweaked particle configuration.

License of media
----------------
See the main MineClone 2 README.md file for license on most of the textures.

For the following textures:
mcl_campfires_campfire_inv.png
mcl_campfires_soul_campfire_inv.png
License: CC0 1.0 Universal (CC0 1.0)
Author: RandomLegoBrick
