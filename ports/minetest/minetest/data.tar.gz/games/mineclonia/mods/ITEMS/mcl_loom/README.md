mcl_loom
--------
Looms, by PrairieWind

Adds Looms to MineClone 2/5. Used to add patterns to banners.

License of source code
----------------------
LGPLv2.1

License of media
----------------

loom_bottom.png
loom_front.png
loom_side.png
loom_top.png
License: CC BY-SA 4.0
Author: MrRar
