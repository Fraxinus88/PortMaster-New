Flowlib
================
Simple flow functions for use in Minetest mods by Qwertymine3

License of source code:
-----------------------
WTFPL
