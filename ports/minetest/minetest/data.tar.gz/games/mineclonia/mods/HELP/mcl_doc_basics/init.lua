--[[
Basic help for MCL2. Fork of doc_basics
]]

dofile(minetest.get_modpath(minetest.get_current_modname()).."/basics.lua")
dofile(minetest.get_modpath(minetest.get_current_modname()).."/advanced.lua")
